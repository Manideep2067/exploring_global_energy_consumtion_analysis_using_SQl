SQL project analyzing global energy consumption, GDP, population, and emissions



# **Global Energy Consumption Analysis (SQL Project)**

&nbsp;Project Overview



This project focuses on analyzing global energy data using SQL to understand patterns in energy production, consumption, emissions, population, and economic growth.



The goal is to transform raw data into meaningful insights that help understand energy usage and support smarter, data-driven decisions for a sustainable future.



&nbsp;Objectives



&nbsp;Analyze energy consumption and production across countries

&nbsp;Identify emission trends and environmental impact

&nbsp;Study the relationship between GDP and energy usage

&nbsp;Calculate per capita metrics for fair comparison

&nbsp;Detect energy dependency among nations

&nbsp;Generate insights for better energy planning



🗄️ Database Structure



The project uses a relational database with 6 connected tables:



🔹 Country



Contains the list of countries and acts as the main table.



🔹 Emission



Stores carbon emission data by country, energy type, and year.



🔹 Consumption



Shows how much energy each country uses.



🔹 Production



Tracks the amount of energy produced by countries.



🔹 Population



Provides yearly population data used for per capita analysis.



🔹 GDP



Represents the economic performance of countries.



&nbsp;Relationship:

The database follows a One-to-Many relationship, where one country can have multiple records in other tables.



&nbsp;Tools Used



SQL Server – Data storage and analysis



SQL – Writing queries and extracting insights



PowerPoint – Presenting findings



&nbsp;Key Analysis Performed



Total emissions by country



Top countries by GDP



Production vs Consumption comparison



Energy consumption per capita



Emission-to-GDP ratio



Global emission share



Population vs emission analysis



Trend analysis over time



&nbsp;Key Insights



✔ Economic growth strongly influences energy consumption and emissions.

✔ Some countries consume more energy than they produce, indicating dependency on imports.

✔ Per capita metrics reveal significant differences in energy usage among countries.

✔ A small number of countries contribute heavily to global emissions.

✔ Sustainable energy practices are essential for reducing environmental impact.



&nbsp;Conclusion



This project demonstrates how data analytics can convert complex energy data into valuable insights. The findings can help organizations and policymakers make informed decisions toward efficient energy management and a more sustainable future.

